# IndianCoffeeBeans — Media Kit

Press page: https://www.indiancoffeebeans.com/press

## About IndianCoffeeBeans

### Short

IndianCoffeeBeans is an independent platform for discovering Indian specialty coffee: roasters, coffees, community ratings, industry data, and guides to how Indian coffee is grown and brewed.

### Standard

IndianCoffeeBeans is an independent discovery platform for India's specialty coffee ecosystem. It catalogues Indian roasters and the coffees they sell, with structured details such as origin region, estate, processing method, roast level and price, so people can compare beans side by side. Coffee drinkers add ratings and reviews, and the platform publishes original catalog data through its Industry Insights dashboard, alongside an editorial field guide on Indian coffee regions, processing and brewing.

### Extended

IndianCoffeeBeans is an independent discovery platform for India's specialty coffee ecosystem, founded in 2024 by Thrilok Abhishek.

The platform catalogues Indian specialty roasters and the coffees they sell, recording structured details for each coffee: origin region and estate, processing method, roast level, varieties, tasting notes and price. Coffee drinkers can filter the catalogue by what matters to them, from brew method to process, and follow each listing through to the roaster's own store. Community members rate and review the coffees they have tried, building a shared record of how Indian coffees taste in practice.

Because the catalogue is structured, it also works as a lens on the industry. The Industry Insights dashboard publishes aggregated, regularly refreshed data on processing trends, origin regions, pricing and roaster geography. The editorial field guide adds multi-part series on India's coffee regions, processing methods, pricing and home brewing, written for curious newcomers and experienced drinkers alike.

IndianCoffeeBeans does not sell coffee; it links to roasters directly.

## Founder

### Short bio

Thrilok Abhishek is the founder of IndianCoffeeBeans. A sales and marketing professional by trade, he built the platform in 2024 as the straightforward, independent resource on Indian specialty coffee he wished he had when he started brewing.

### Long bio

Thrilok Abhishek is the founder of IndianCoffeeBeans, an independent discovery platform for Indian specialty coffee.

His interest in coffee began with South Indian filter coffee at home, and deepened during six to seven months in Italy in 2012, where he was drawn into its espresso culture. After the pandemic, a casual habit became a serious one: from instant coffee to a full home brewing station and a growing collection of Indian beans.

A sales and marketing professional by trade, Thrilok approached the project from the drinker's side, asking what he would have wanted when starting out. The answer was a comprehensive resource focused on Indian coffee and free of marketing noise. He credits the r/IndianCoffee community as his main guide through India's coffee landscape, and describes IndianCoffeeBeans as his way of giving back to it.

Portrait: founder/thrilok-abhishek-founder.jpg (Photo: courtesy of IndianCoffeeBeans)

## Brand usage

- Keep the logo's original proportions; don't stretch, skew or crop it.
- Don't recolour the logo or add effects. Use the light wordmark on dark backgrounds and the primary or dark wordmark on light ones.
- Leave clear space around the logo of at least the height of the icon's smaller bean.
- Don't use the logo in a way that suggests IndianCoffeeBeans endorses a third party, product or roaster.
- Credit IndianCoffeeBeans when reproducing its data or editorial material, and link to the source page where possible.

## Data attribution

When citing ICB data: "Source: IndianCoffeeBeans.com — Industry Insights" (https://www.indiancoffeebeans.com/learn/insights).
Published, aggregated insights may be cited with attribution. The underlying dataset is not licensed for reproduction;
for custom data, bulk exports or licensing see https://www.indiancoffeebeans.com/developers or email thrilok.gt@indiancoffeebeans.com.

## Contact

Media enquiries: thrilok.gt@indiancoffeebeans.com
